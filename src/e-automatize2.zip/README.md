# 🌐 E-Automatize2

Site OnePage em React + Vite com integração SendPulse.

## 🚀 Como rodar localmente

```bash
npm install
npm run dev
```

Acesse em: http://localhost:5173

## ☁️ Deploy no GitHub Pages

1. Crie o repositório no GitHub chamado **E-automatize2**
2. No terminal:
   ```bash
   git init
   git add .
   git commit -m "Primeiro commit"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/E-automatize2.git
   git push -u origin main
   ```
3. Depois rode:
   ```bash
   npm run deploy
   ```

O site ficará disponível em:  
👉 https://SEU_USUARIO.github.io/E-automatize2/
