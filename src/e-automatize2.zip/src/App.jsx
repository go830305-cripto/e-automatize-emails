import React from 'react'

function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', textAlign: 'center' }}>
      <header style={{ backgroundColor: '#0089bf', color: '#fff', padding: '3rem 1rem' }}>
        <h1>E-Automatize</h1>
        <p>Automatize seus processos com eficiência e inteligência.</p>
      </header>

      <section style={{ padding: '2rem', maxWidth: '700px', margin: '0 auto' }}>
        <h2>Sobre Nós</h2>
        <p>
          A E-Automatize é especializada em soluções automatizadas para empresas e profissionais.
          Transforme sua comunicação e aumente sua produtividade.
        </p>
      </section>

      <section style={{ backgroundColor: '#f9f9f9', padding: '2rem 0' }}>
        <h2>Assine nossa newsletter</h2>
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '1rem' }}>
          <div dangerouslySetInnerHTML={{ __html: `
          <script src="//web.webformscr.com/apps/fc3/build/loader.js" async sp-form-id="a6bbc232d6fced53fa53e9b05819b5b6c37ffaf0b303dd05bf25f60fda1eae64"></script>
          <div class="sp-form-outer sp-force-hide">
            <div id="sp-form-250085" sp-id="250085" sp-hash="a6bbc232d6fced53fa53e9b05819b5b6c37ffaf0b303dd05bf25f60fda1eae64" class="sp-form sp-form-regular">
            </div>
          </div>
          <script type="text/javascript" async src="//web.webformscr.com/apps/fc3/build/default-handler.js"></script>
          `}} />
        </div>
      </section>

      <footer style={{ backgroundColor: '#0089bf', color: '#fff', padding: '1rem', marginTop: '2rem' }}>
        <p>© 2025 E-Automatize - Todos os direitos reservados.</p>
      </footer>
    </div>
  )
}

export default App
